# Threedigrid version number is automatic updated with zest.releaser
# the version number in setup.py is updated using the find_version()
__version__ = "1.2.0"
