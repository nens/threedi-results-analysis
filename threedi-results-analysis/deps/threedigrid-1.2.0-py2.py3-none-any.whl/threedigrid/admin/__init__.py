"""
The admin module hosts all functionality that is necessary to connect to the
grid administration file. That is, the data can be read, altered, serialized
and exported by the classes and methods implemented here.
"""
